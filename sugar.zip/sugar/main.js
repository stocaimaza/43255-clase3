/** SUGAR SYNTAX **/

//¿Qué es? La utilización de operadores avanzados con la idea de simplificar el código. 

//1) Plantillas Literales: Las usamos a traves de las backsticks ``
//alt + 96. Esto me permite simplificar la concatenación de datos. 

let nombre = "Pepe Argento"; 
let trabajo = "Zapatería"; 

let mensaje = `${nombre} trabaja en una ${trabajo}`;

console.log(mensaje);

//2) Operador Ternario: Es una simplificación de la estructura if/else.

//Sintaxis: condicion ? codigoSiEsVerdad : codigoSiEsFalso; 

let frio = true;

console.log(frio ? "mira netflix con la estufa" : "hacemos un picnic" );

let respuesta = frio ? "tortas fritas y star+" : "hacemos un asado"; 

console.log(respuesta);

//3) Operador Spread: Operador de Propagación. (...)
//Se utiliza con elementos iterables ( arrays, objetos ) enviando cada uno de sus elementos como parámetros a una función. 

let nombres = ["Juan", "Pedro", "Maria", "Jose"]; 

console.log(nombres);

//Peeeeeeeeero si utilizo el operador Spread: 

console.log(...nombres);

console.log(nombres[0], nombres[1], nombres[2], nombres[3]);

//Copiar objetos: 

const alumno = {
    nombre: "Coki", 
    apellido: "Argento", 
    edad: 45
};

const alumnoDos = alumno; 
//NO HACEMOS ESTO!!


alumno.nombre = "Pepe";

//console.log(alumnoDos);
//console.log(alumno);

//Si hago esto estoy copiando la referencia en memoria. 

//Para copiar la información de forma correcta utilizo el operador Spread: 

const alumnoTres = {...alumno};

console.log(alumnoTres);
console.log(alumno);

alumnoTres.nombre = "Fatiga";

console.log(alumnoTres);
console.log(alumno);

//Copiamos arrays: 

const a = [1,2,3];
const b = [4,5,6];

const nuevoArray = [...a, ...b];
console.log(nuevoArray);

//4) Desestructuración de Objetos: 
//Es una expresión de JS que me permite desempaquetar valores de arrays u objetos en distintas variables. 

//Ejemplo: 

const bart = {
    nombre: "Bart",
    apellido: "Simpson",
    edad: 10, 
    escuela: "Sprinfield Elementary School"
}; 

//Hago lo siguiente: 

let {nombre:nombrecito, apellido, edad, escuela, mascota} = bart;

console.log(nombrecito);
console.log(edad);
console.log(escuela);
console.log(mascota);

//5) Desestructuración de Arrays: 

let frutas = ["Manzana", "Pera", "Naranja", "Vino"];

let [,,fruta3, fruta4] = frutas;

console.log(fruta3);

//6) Acceso Condicional a Propiedades de un Objeto.  (?)

const empleado = null; 

console.log(empleado?.nombre); 

alert("Ayudame loco!");
//Lo utilizo para controlar errores y evitar que se rompa la aplicación. 







